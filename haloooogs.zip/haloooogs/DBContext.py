import  datetime
import pymongo
from pymongo.collection import Collection
from pymongo.database import Database
import cfg 
from pymongo.write_concern import WriteConcern
import json
import requests

class DbContext:
    

    def __init__(self):
        
        print("initializing Data Base Context" )



    def create_TTL_collection(self, collectionName):
        client = pymongo.MongoClient(cfg.URI)
        database = client[cfg.DATABASE_NAME]
        collection = database[collectionName]

        indexes = collection.list_indexes()

        indexes = [n['name'] for n in indexes]

        if(cfg.RUN_TIME_STATS_INDEX_FIELD+"_1" in indexes):
            #ret = self.change_TTL_value(collectionName)
            return True
        else:
            ret = collection.create_index( cfg.RUN_TIME_STATS_INDEX_FIELD, expireAfterSeconds=cfg.LOG_CONFIG.runtimeStatsExpireTime )

        return ret

    def change_TTL_value(self, collectionName):
        client = pymongo.MongoClient(cfg.URI)
        database = client[cfg.DATABASE_NAME]
        ret = database.command({ 'collMod': collectionName, 
        'index': { 'keyPattern': { cfg.RUN_TIME_STATS_INDEX_FIELD: 1 }, 'expireAfterSeconds': cfg.LOG_CONFIG.runtimeStatsExpireTime } })

        return ret

    def get_configuration(self):
        client = pymongo.MongoClient(cfg.URI)
        database = client[cfg.DATABASE_NAME]
        collection = database['configuration']

        doc = collection.find_one({"_id":-1})
        
        if(not doc):
            return False

        if('runtimeStatsPeriod' in doc):
            cfg.LOG_CONFIG.runtimeStatsPeriod = doc['runtimeStatsPeriod']

        if('runtimeStatsExpireTime' in doc):
            cfg.LOG_CONFIG.runtimeStatsExpireTime = doc['runtimeStatsExpireTime']

        if('getRequests' in doc):
            cfg.LOG_CONFIG.getRequests = doc['getRequests']

        if('requestsBufferSize' in doc):
            cfg.LOG_CONFIG.requestsBufferSize = doc['requestsBufferSize']

        if('globalLogsTime' in doc):
            cfg.LOG_CONFIG.globalLogsTime = doc['globalLogsTime']

        return True


    def write_log_record(self, collectionName, log_record):
        client = pymongo.MongoClient(cfg.URI)
        database = client[cfg.DATABASE_NAME]
        collection = database[collectionName]


        date = datetime.datetime.now()

        document_id = str(date.year) + "_" + str(date.month) + "_" + str(date.day)
        t = str(date.hour) + ":" + str(date.minute) + ":" + str(date.second)

        filter = {'_id': document_id}
        
        if(type(log_record) == str):
            update = { '$push': {'logs':{ 'time': t,"msg": log_record }} }
        elif(type(log_record) == list):
            update = { '$push': {'logs':{ '$each':  log_record }} }
        
        ret = collection.update_one(filter, update, upsert=True)
        
        return ret
        

    def write_runtime_logs(self, collectionName, logs):
        client = pymongo.MongoClient(cfg.URI)
        database = client[cfg.DATABASE_NAME]
        collection = database[collectionName]
        
        print("Before Insert: ")
        ret = collection.insert_one(logs)
        print("After Insert: ", ret)
        return ret
    
    
    def check_mongo_connection(self) -> bool:
        client = pymongo.MongoClient(cfg.URI)
        client2 = pymongo.MongoClient(cfg.URI1)
        database = client[cfg.DATABASE_NAME]
        database2 = client2[cfg.DATABASE_NAME]
        
        print("Trying connect to MongoDB..............")
        ret = database2.command({'connectionStatus': 1, 'showPrivileges': True } )
        print( ret)
        
        print("Trying insert to Test Collection..............")
        collection = database["testCollection"]   
        # collection = collection.with_options(write_concern=WriteConcern(w=0))
        ret = collection.insert_one({"re":"n" * 1000})

        # response = self.send_req({"magdy":"m" * 10000000})
        # print(response)
        
        
        # print("Trying drop Test Collection..............")
        # collection.drop()
        print("successfully connected")
        
        return True
    
    def send_req(self, payload):

        # print("Trying drop Test Collection..............")

        url = "http://10.0.0.54:20181"

        headers = {
        'Content-Type': 'application/json'
        }

        response = requests.request("POST", url, headers=headers, json=payload)

        # print(response.text)

        return response.text.replace("\n", "")
    
    
    def send_multiple(self):
        
        
        for i in range(1000):
            response = self.send_req({"magdy":"V" * i*100000})
            print(response)
            