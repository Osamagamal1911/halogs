from datetime import datetime
import  time
from DBContext import DbContext
from BackendListener import BackendListener
import cfg
import threading
from haproxy_Runtime import HA_Runtime
from typing import *
from models import NODE_TYPE

def start_listen_debug(backend, context:DbContext, globalLog= False):

    listener = BackendListener(backend[0], backend[1], context)

    if(globalLog):
        # listener.get_global_logs()
        listener.print_global_logs(["orchestratorapi"])
    else:
        listener.get_logs()


def start_listen(backend, context:DbContext, globalLog= False):

    listener = BackendListener(backend[0], backend[1], context)

    if(globalLog):
        listener.get_global_logs()
    else:
        listener.get_logs()

def pop_nodeType(l):
    ret = []
    for x in l:
        x.pop('nodeType')
        ret.append(x)
        
    return ret

def runtimeStats(context: DbContext):
    print('startedA runtime stats thread')

    context.create_TTL_collection(cfg.RUN_TIME_STATS_COLLECTION_NAME)
    expireTime = cfg.LOG_CONFIG.runtimeStatsExpireTime

    while True:
        context.get_configuration()

        ha = HA_Runtime()
        #print([x['nodeType'] for x in ha.logs])
        
        if(cfg.LOG_CONFIG.runtimeStatsExpireTime != expireTime):
            #context.change_TTL_value(cfg.RUN_TIME_STATS_COLLECTION_NAME)
            expireTime = cfg.LOG_CONFIG.runtimeStatsExpireTime

        haproxy = pop_nodeType([ x for x in ha.logs if x['nodeType'] == NODE_TYPE.haproxy.value])
        
        if(len(haproxy)):
            haproxy = haproxy[0]
        else:
            haproxy = None
            

        haproxyproc = pop_nodeType([ x for x in ha.logs if 'nodeType' in x and x['nodeType'] == NODE_TYPE.haproxyProcess.value])
        
        if(len(haproxyproc) == 1):
            haproxyproc = haproxyproc[0]
        elif(len(haproxyproc) == 0):
            haproxyproc = None
            
            
        doc = {'createdAt' : datetime.now()
               , 'haproxy': haproxy
               , 'haproxyProcess': haproxyproc
               , 'backends': pop_nodeType([ x for x in ha.logs if 'nodeType' in x and x['nodeType'] == NODE_TYPE.backend.value])
               , 'frontends': pop_nodeType([ x for x in ha.logs if 'nodeType' in x and x['nodeType'] == NODE_TYPE.frontend.value])
               , 'servers': pop_nodeType([ x for x in ha.logs if 'nodeType' in x and x['nodeType'] == NODE_TYPE.server.value])
               
               }
        context.write_runtime_logs(cfg.RUN_TIME_STATS_COLLECTION_NAME, doc) 

        time.sleep(cfg.LOG_CONFIG.runtimeStatsPeriod)


def main():
    context = DbContext()

    while (True):
        ret = context.check_mongo_connection()
        if(ret):
            break
        
        time.sleep(10)
        
    threadList = []

    threadList.append( threading.Thread(target=runtimeStats, args=(context,)))
    threadList.append( threading.Thread(target=start_listen, args=(cfg.GLOBAL,context,True,)))

    for backend in cfg.BACKENDs:
       threadList.append( threading.Thread(target=start_listen, args=(backend,context,)))

    for t in threadList:
        t.start()
        

    for t in threadList:
        t.join()

    print("finished")

if __name__ == "__main__":
    main()
