from flask import Flask
from flask import request, json
import requests
from flask_cors import cross_origin

IPAddr, Port = "10.0.0.173", 20181

app = Flask(__name__)


@app.route('/', methods=['POST'])
@cross_origin()
def catch_all():
    res = "BadRequest"
    statusCode = 500
    
    
    try:
        payload = request.get_json()
        # db_context.corpus_collection.insert_one(payload)
        
        statusCode = 200
        response = {"size": len(str(payload))}
        print(payload, response)
        return response, statusCode
        
    except Exception as e:
        res = "Exception: " + str(e)
                
    return res, statusCode


if __name__ == '__main__':
    app.run(host=IPAddr, port=Port, debug=True)
