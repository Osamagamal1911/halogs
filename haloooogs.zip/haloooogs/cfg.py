from datetime import datetime

URI1 = "mongodb://admin:admin@10.0.0.124:20191,10.0.0.54:20191,10.0.0.219:20191/?authsource=admin&replicaset=alkhwarizmirepl"
URI = "mongodb://admin:admin@10.0.0.124:20191,10.0.0.54:20191,10.0.0.219:20191/?authsource=admin&replicaset=alkhwarizmirepl"
# URI = "mongodb://admin:admin@10.0.0.219:20191/?authsource=admin&replicaset=alkhwarizmirepl"
# URI = "mongodb://admin:admin@10.0.0.54:20191/?authsource=admin&replicaset=alkhwarizmirepl"
# URI = "mongodb://admin:admin@10.0.0.124:20191/?authsource=admin&replicaset=alkhwarizmirepl"
# URI = "mongodb://admin:admin@10.0.0.54:20191/?replicaset=alkhwarizmirepl"
# URI = "mongodb://10.0.0.54:20181/"
DATABASE_NAME = "HALogs_Node2"

HAPROXY_LOGS_HOST = "127.0.0.1"

RUN_TIME_STATS_COLLECTION_NAME = "runtimeStats"
RUN_TIME_STATS_INDEX_FIELD = "createdAt"

BACKENDs = {
 ('alkhwarizmiPlatformwww' , 65001 ),
        ('orchestrator', 65002 ),
        ('testbot', 65003 ),
        ('app-whatsapp', 65004 ),
        ('app-unifonic', 65005 ),
        ('bab-whatsapp', 65006 ),
        ('graph-facebook', 65007 ),
        ('twillo', 65008 ),
        ('twitter', 65009 ),
        ('GacaMW', 65010 ),
        ('MohMW', 65011 ),
        ('monitor', 65012 ),
        ('alkhwarizmiPlatform', 65013 ),
        ('resources', 65014 ),
        ('orchbackend', 65015 ),
        ('adscampaign', 65016 ),
        ('livechat', 65017 ),
        ('gpt', 65018 ),
        ('tvtc', 65019 ),
        ('accounts', 65020 ),
        ('seda', 65021 ),
        ('orchestratorapi', 65023 )

}

GLOBAL =  ('global' , 65022 )


class LogConfig:
    runtimeStatsPeriod = 10
    runtimeStatsExpireTime = 720
    requestsBufferSize = 10
    globalLogsTime = datetime.min


LOG_CONFIG: LogConfig = LogConfig()


