from haproxyadmin import haproxy
from haproxyadmin.internal.backend import _Backend
from typing import *
from models import *

class HA_Runtime:
    server_dir = '/var/run'
    server_address = '/var/run/haproxy.sock'
    ha: haproxy.HAProxy
    hap: haproxy._HAProxyProcess

    logs: List[log_record] = []
    
    def __init__(self) -> None:
        self.logs = []
        self.ha = haproxy.HAProxy(socket_dir=self.server_dir)
        
        record = ha_log_record(len(self.logs), self.ha)
        self.logs.append(record.__dict__)

        self.hap = haproxy._HAProxyProcess(socket_file=self.server_address)
        record = hap_log_record(len(self.logs), self.hap)
        #self.logs.append(record.__dict__)


        fronts = self.hap.frontends()
        for f in fronts:
            record = frontend_log_record(len(self.logs), f)
            self.logs.append(record.__dict__)


        backs: List[_Backend] = self.hap.backends()
        for b in backs:
            record = backend_log_record(len(self.logs), b, self.hap)
            self.logs.append(record.__dict__)

            for s in b.servers():
                record = server_log_record(len(self.logs), s)
                self.logs.append(record.__dict__)
 
