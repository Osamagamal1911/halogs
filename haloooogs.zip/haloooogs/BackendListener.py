from datetime import datetime, timedelta
import  time
import  socket
from DBContext import DbContext
import cfg
from typing import *


class BackendListener:
    context: DbContext
    sock: socket.socket
    backend_name: str
    
    buffer = []

    def __init__(self, backend_name, port, context:DbContext):
        self.backend_name = backend_name
        self.context = context

        self.get_Socket(port)



    def get_Socket(self, port):

        self.sock = socket.socket(socket.AF_INET, # Internet
                            socket.SOCK_DGRAM) # UDP
        self.sock.bind((cfg.HAPROXY_LOGS_HOST, port))
        
        local_time = time.ctime()
        print("Start Listen to port: ", port)	
        print("start getting logs Local time:", local_time)	
        

    def close_socket(self):
        self.sock.close()

    def get_logs(self):

        Buffer = ""

        while True:
            data, addr = self.sock.recvfrom(1024) # buffer size is 1024 bytes
            Buffer += data.decode("utf-8") 

            LogRecords = Buffer.split("\n")

            Buffer = LogRecords[-1]

            LogRecords = LogRecords[:-1]

            for record in LogRecords:
                content = record.split(',')
                if(not len(content)):
                    continue
                
                content = content[0]

                content = content.split(': ')
                if(not len(content)):
                    continue
                content = content[1]
                
                
                print(self.backend_name, ":",content)
                self.context.write_log_record(self.backend_name ,content)

        self.close_socket()

    def get_global_logs(self):

        Buffer = ""

        while True:

            date_now = datetime.now()

            if(date_now > cfg.LOG_CONFIG.globalLogsTime ):
                time.sleep(10)
                continue

            data, addr = self.sock.recvfrom(1024) # buffer size is 1024 bytes
            Buffer += data.decode("utf-8") 

            LogRecords = Buffer.split("\n")

            Buffer = LogRecords[-1]

            LogRecords = LogRecords[:-1]

            for record in LogRecords:
                content = record.split(']: ')
                if(not len(content)):
                    continue
                
                content = content[-1]

                print(self.backend_name, ":",content)

                date = datetime.now()

                t = str(date.hour) + ":" + str(date.minute) + ":" + str(date.second)

                self.buffer.append({ 'time': t,"msg": content })
                # print(content)
                if(len(self.buffer) < cfg.LOG_CONFIG.requestsBufferSize):
                    continue

                self.context.write_log_record(self.backend_name ,self.buffer)
                self.buffer.clear()

                
        self.close_socket()


    def print_global_logs(self, backends = []):

        Buffer = ""

        while True:

            data, addr = self.sock.recvfrom(1024) # buffer size is 1024 bytes
            Buffer += data.decode("utf-8") 

            LogRecords = Buffer.split("\n")

            Buffer = LogRecords[-1]

            LogRecords = LogRecords[:-1]

            for record in LogRecords:
                content = record.split(']: ')
                if(not len(content)):
                    continue
                
                content = content[-1]

                pp = False
                
                
                if(backends == []):
                    pp = True
                else:
                    for bk in backends:
                        if(bk in content):
                            pp = True
                            
                if(pp):
                    print(content)
                    
        self.close_socket()



    def get_bks_stats(self, period): #period in seconds
        
        stats = dict()
        
        for bk, port in cfg.BACKENDs:
            stats[bk] = 0
            
        Buffer = ""

        start = datetime.now()
        end  = start + timedelta(seconds=period)

        
        while True:

            data, addr = self.sock.recvfrom(1024) # buffer size is 1024 bytes
            Buffer += data.decode("utf-8") 

            LogRecords = Buffer.split("\n")

            Buffer = LogRecords[-1]

            LogRecords = LogRecords[:-1]

            for record in LogRecords:
                content = record.split(']: ')
                if(not len(content)):
                    continue
                
                content = content[-1]                

                for bk, port in cfg.BACKENDs:
                    if(bk in content):
                        stats[bk] += 1

            date_now = datetime.now()
            
            if(date_now > end):
                break
            
        for k , v in stats.items():
            print(k, ": ", v)
        self.close_socket()

